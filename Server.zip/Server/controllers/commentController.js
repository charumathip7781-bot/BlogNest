const Comment = require("../models/commentModel");
const Post = require("../models/postModel");
const Analytics = require("../models/analyticsModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { ELEVATED_ROLES } = require("../constants/roles");

exports.create = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.postId);
  if (!post || post.status !== "published") throw new AppError("Post not found", 404);

  const comment = await Comment.create({
    postID: post._id,
    userID: req.user._id,
    message: req.body.message,
    status: "pending",
  });
  await Analytics.create({ postID: post._id, userID: req.user._id, type: "comment" });
  const data = await Comment.findById(comment._id).populate("userID", "name");
  res.status(201).json({ success: true, data });
});

exports.list = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.postId);
  if (!post) throw new AppError("Post not found", 404);
  if (post.status !== "published" && !(req.user && ELEVATED_ROLES.includes(req.user.role))) {
    throw new AppError("Post not found", 404);
  }

  const filter = { postID: post._id };
  const elevated = req.user && ELEVATED_ROLES.includes(req.user.role);
  if (!elevated) {
    filter.$or = [{ status: "approved" }];
    if (req.user) filter.$or.push({ userID: req.user._id });
  } else if (req.query.status) {
    filter.status = req.query.status;
  }

  const data = await Comment.find(filter).populate("userID", "name").sort({ createdAt: -1 });
  res.json({ success: true, data });
});

exports.moderate = asyncHandler(async (req, res) => {
  const comment = await Comment.findByIdAndUpdate(
    req.params.id,
    { status: req.body.status },
    { new: true, runValidators: true }
  ).populate("userID", "name");
  if (!comment) throw new AppError("Comment not found", 404);
  res.json({ success: true, data: comment });
});

exports.remove = asyncHandler(async (req, res) => {
  const comment = await Comment.findById(req.params.id);
  if (!comment) throw new AppError("Comment not found", 404);
  const elevated = ELEVATED_ROLES.includes(req.user.role);
  const owner = comment.userID.equals(req.user._id);
  if (!elevated && !owner) throw new AppError("You cannot remove this comment", 403);
  await comment.deleteOne();
  res.json({ success: true, message: "Comment removed" });
});
