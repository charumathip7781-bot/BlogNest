const Tag = require("../models/tagModel");
const Post = require("../models/postModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { escapeRegex, slugify } = require("../utils/slug");
const { uniqueSlug } = require("../services/taxonomy");

exports.list = asyncHandler(async (req, res) => {
  const data = await Tag.find().sort({ name: 1 });
  res.json({ success: true, data });
});

exports.create = asyncHandler(async (req, res) => {
  const name = req.body.name.trim();
  const existing = await Tag.findOne({ name: new RegExp(`^${escapeRegex(name)}$`, "i") });
  if (existing) throw new AppError("Tag already exists", 409);
  const data = await Tag.create({
    name,
    slug: await uniqueSlug(Tag, slugify(name)),
  });
  res.status(201).json({ success: true, data });
});

exports.remove = asyncHandler(async (req, res) => {
  const tag = await Tag.findById(req.params.id);
  if (!tag) throw new AppError("Tag not found", 404);
  await Post.updateMany({ tags: tag._id }, { $pull: { tags: tag._id } });
  await tag.deleteOne();
  res.json({ success: true, message: "Tag removed" });
});
