const Post = require("../models/postModel");
const Tag = require("../models/tagModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const blogGenerator = require("../services/blogGenerator");
const { resolveDocuments } = require("../services/taxonomy");
const { ELEVATED_ROLES, ROLES } = require("../constants/roles");

function canEdit(post, user) {
  if (ELEVATED_ROLES.includes(user.role)) return true;
  return user.role === ROLES.AUTHOR && post.userID.equals(user._id);
}

exports.generateBlog = asyncHandler(async (req, res) => {
  const topic = String(req.body.topic || "").trim();
  if (topic.length < 3 || topic.length > 300) {
    throw new AppError("topic must be 3 to 300 characters", 400);
  }

  const generated = await blogGenerator.generateBlog({
    topic,
    tone: req.body.tone,
    audience: req.body.audience,
    keywords: req.body.keywords,
  });
  if (generated.title.trim().length < 3) generated.title = "Untitled draft";

  let post = null;
  if (req.body.save) {
    post = await Post.create({
      userID: req.user._id,
      name: generated.title,
      message: generated.content,
      summary: generated.summary,
      tags: await resolveDocuments(Tag, generated.tags),
      status: "draft",
    });
  }

  res.status(201).json({ success: true, data: { ...generated, post } });
});

exports.summarize = asyncHandler(async (req, res) => {
  let content = req.body.content ? String(req.body.content) : "";
  let post = null;

  if (req.body.postId) {
    post = await Post.findById(req.body.postId);
    if (!post) throw new AppError("Post not found", 404);
    if (!canEdit(post, req.user) && post.status !== "published") {
      throw new AppError("Post not found", 404);
    }
    content = content || post.message;
  }

  if (content.trim().length < 20) {
    throw new AppError("content must be at least 20 characters", 400);
  }
  if (content.length > 20000) throw new AppError("content is too long", 400);

  const summary = await blogGenerator.summarize(content);
  if (post && canEdit(post, req.user)) {
    post.summary = summary.summary;
    await post.save();
  }

  res.json({ success: true, data: summary });
});

exports.faq = asyncHandler(async (req, res) => {
  const topic = String(req.body.topic || "").trim();
  const content = String(req.body.content || "").trim();
  if (topic.length < 3 && content.length < 20) {
    throw new AppError("Provide a topic or source content", 400);
  }
  const data = await blogGenerator.faq({ topic, content });
  res.json({ success: true, data });
});

exports.weatherWise = asyncHandler(async (req, res) => {
  const location = String(req.body.location || "").trim();
  if (location.length < 2 || location.length > 80) {
    throw new AppError("location must be 2 to 80 characters", 400);
  }
  const data = await blogGenerator.weatherWise({
    location,
    conditions: req.body.conditions,
  });
  res.json({
    success: true,
    disclaimer: "WeatherWise notes are generated guidance, not a live forecast.",
    data,
  });
});

exports.fitTrack = asyncHandler(async (req, res) => {
  const goal = String(req.body.goal || "").trim();
  if (goal.length < 2 || goal.length > 200) {
    throw new AppError("goal must be 2 to 200 characters", 400);
  }
  const data = await blogGenerator.fitTrack({
    goal,
    level: req.body.level,
    constraints: req.body.constraints,
  });
  res.json({
    success: true,
    disclaimer: "FitTrack suggestions are general information, not medical advice.",
    data,
  });
});
