const jwt = require("jsonwebtoken");
const User = require("../models/userModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { publicUser } = require("../utils/publicUser");
const { ROLES } = require("../constants/roles");

function signToken(user) {
  return jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || "7d",
  });
}

exports.register = asyncHandler(async (req, res) => {
  const admins = await User.countDocuments({ role: ROLES.ADMIN });
  const role = admins === 0 ? ROLES.ADMIN : ROLES.AUTHOR;
  const user = await User.create({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password,
    role,
  });

  res.status(201).json({
    success: true,
    message: role === ROLES.ADMIN ? "Bootstrap admin account created" : "Account created",
    token: signToken(user),
    data: publicUser(user),
  });
});

exports.login = asyncHandler(async (req, res) => {
  const user = await User.findOne({ email: req.body.email }).select("+password");
  if (!user || !(await user.comparePassword(req.body.password))) {
    throw new AppError("Invalid email or password", 401);
  }

  res.json({
    success: true,
    token: signToken(user),
    data: publicUser(user),
  });
});

exports.me = asyncHandler(async (req, res) => {
  res.json({ success: true, data: publicUser(req.user) });
});
