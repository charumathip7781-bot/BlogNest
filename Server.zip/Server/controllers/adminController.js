const logger = require("../utils/logger");

exports.logs = (req, res) => {
  res.json({ success: true, data: logger.list() });
};
