const Category = require("../models/categoryModel");
const Post = require("../models/postModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { escapeRegex, slugify } = require("../utils/slug");
const { uniqueSlug } = require("../services/taxonomy");

async function findByName(name) {
  return Category.findOne({ name: new RegExp(`^${escapeRegex(name)}$`, "i") });
}

exports.list = asyncHandler(async (req, res) => {
  const data = await Category.find().sort({ name: 1 });
  res.json({ success: true, data });
});

exports.create = asyncHandler(async (req, res) => {
  const name = req.body.name.trim();
  if (await findByName(name)) throw new AppError("Category already exists", 409);
  const data = await Category.create({
    name,
    slug: await uniqueSlug(Category, slugify(name)),
    description: req.body.description || "",
  });
  res.status(201).json({ success: true, data });
});

exports.update = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);
  if (!category) throw new AppError("Category not found", 404);
  if (req.body.name) {
    const name = req.body.name.trim();
    const existing = await findByName(name);
    if (existing && !existing._id.equals(category._id)) {
      throw new AppError("Category already exists", 409);
    }
    category.name = name;
    category.slug = await uniqueSlug(Category, slugify(name), category._id);
  }
  if (req.body.description !== undefined) category.description = req.body.description;
  await category.save();
  res.json({ success: true, data: category });
});

exports.remove = asyncHandler(async (req, res) => {
  const category = await Category.findById(req.params.id);
  if (!category) throw new AppError("Category not found", 404);
  await Post.updateMany({ categories: category._id }, { $pull: { categories: category._id } });
  await category.deleteOne();
  res.json({ success: true, message: "Category removed" });
});
