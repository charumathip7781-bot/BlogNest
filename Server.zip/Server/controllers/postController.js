const Post = require("../models/postModel");
const Category = require("../models/categoryModel");
const Tag = require("../models/tagModel");
const Comment = require("../models/commentModel");
const Analytics = require("../models/analyticsModel");
const Media = require("../models/mediaModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { getPage } = require("../utils/pagination");
const { escapeRegex } = require("../utils/slug");
const { isSafeMediaPath } = require("../utils/mediaPath");
const { resolveDocuments } = require("../services/taxonomy");
const { applyStatus, publishDueScheduledPosts } = require("../services/postLifecycle");
const { ROLES, ELEVATED_ROLES, POST_STATUSES } = require("../constants/roles");

function authorId(post) {
  return post.userID?._id || post.userID;
}

function canEdit(post, user) {
  if (ELEVATED_ROLES.includes(user.role)) return true;
  return user.role === ROLES.AUTHOR && authorId(post).equals(user._id);
}

function populatePost(query) {
  return query
    .populate("userID", "name")
    .populate("categories", "name slug")
    .populate("tags", "name slug");
}

async function applyTaxonomyFilters(filter, query) {
  if (query.category) {
    const category = await Category.findOne({ slug: String(query.category).toLowerCase() });
    if (!category) return false;
    filter.categories = category._id;
  }
  if (query.tag) {
    const tag = await Tag.findOne({ slug: String(query.tag).toLowerCase() });
    if (!tag) return false;
    filter.tags = tag._id;
  }
  if (query.q) {
    const pattern = new RegExp(escapeRegex(String(query.q).slice(0, 100)), "i");
    filter.$or = [{ name: pattern }, { message: pattern }, { summary: pattern }];
  }
  return true;
}

exports.create = asyncHandler(async (req, res) => {
  if (req.body.photo && !isSafeMediaPath(req.body.photo)) {
    throw new AppError("photo must be a relative media path or an http(s) URL", 400);
  }

  const post = new Post({
    userID: req.user._id,
    name: req.body.name,
    message: req.body.message,
    photo: req.body.photo || "",
    categories: await resolveDocuments(Category, req.body.categories),
    tags: await resolveDocuments(Tag, req.body.tags),
  });
  const explicitStatus = Boolean(req.body.status);
  applyStatus(post, req.body.status || "published", req.body.scheduledAt, req.user.role, {
    allowAuthorPublish: !explicitStatus,
  });
  await post.save();
  const data = await populatePost(Post.findById(post._id));
  res.status(201).json({ success: true, data });
});

exports.list = asyncHandler(async (req, res) => {
  await publishDueScheduledPosts();
  const { page, limit, skip } = getPage(req.query);
  const filter = { status: "published" };
  const matched = await applyTaxonomyFilters(filter, req.query);
  if (!matched) {
    return res.json({ success: true, data: [], meta: { page, limit, total: 0 } });
  }

  const [data, total] = await Promise.all([
    populatePost(Post.find(filter).sort({ publishedAt: -1, createdAt: -1 }).skip(skip).limit(limit)),
    Post.countDocuments(filter),
  ]);
  res.json({ success: true, data, meta: { page, limit, total } });
});

exports.mine = asyncHandler(async (req, res) => {
  const { page, limit, skip } = getPage(req.query);
  const filter = { userID: req.user._id };
  if (req.query.status) {
    if (!POST_STATUSES.includes(req.query.status)) {
      throw new AppError("Invalid status filter", 400);
    }
    filter.status = req.query.status;
  }
  const [data, total] = await Promise.all([
    populatePost(Post.find(filter).sort({ updatedAt: -1 }).skip(skip).limit(limit)),
    Post.countDocuments(filter),
  ]);
  res.json({ success: true, data, meta: { page, limit, total } });
});

exports.queue = asyncHandler(async (req, res) => {
  await publishDueScheduledPosts();
  const status = req.query.status || "pending";
  if (!["draft", "pending", "scheduled", "published"].includes(status)) {
    throw new AppError("Invalid status filter", 400);
  }
  const { page, limit, skip } = getPage(req.query);
  const filter = { status };
  const [data, total] = await Promise.all([
    populatePost(Post.find(filter).sort({ updatedAt: -1 }).skip(skip).limit(limit)),
    Post.countDocuments(filter),
  ]);
  res.json({ success: true, data, meta: { page, limit, total } });
});

exports.getOne = asyncHandler(async (req, res) => {
  await publishDueScheduledPosts();
  const post = await populatePost(Post.findById(req.params.id));
  if (!post) throw new AppError("Post not found", 404);

  const elevated = req.user && ELEVATED_ROLES.includes(req.user.role);
  const owner = Boolean(req.user && authorId(post)?.equals(req.user._id));
  if (post.status !== "published" && !elevated && !owner) {
    throw new AppError("Post not found", 404);
  }

  if (post.status === "published" && !owner) {
    await Post.updateOne({ _id: post._id }, { $inc: { views: 1 } });
    post.views += 1;
    await Analytics.create({
      postID: post._id,
      userID: req.user?._id,
      type: "view",
    });
  }

  res.json({ success: true, data: post });
});

exports.update = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw new AppError("Post not found", 404);
  if (!canEdit(post, req.user)) throw new AppError("You can only edit your own posts", 403);

  if (req.body.photo !== undefined) {
    if (req.body.photo && !isSafeMediaPath(req.body.photo)) {
      throw new AppError("photo must be a relative media path or an http(s) URL", 400);
    }
    post.photo = req.body.photo || "";
  }
  if (req.body.name) post.name = req.body.name;
  if (req.body.message) post.message = req.body.message;
  if (req.body.summary !== undefined) post.summary = req.body.summary;
  if (req.body.categories) {
    post.categories = await resolveDocuments(Category, req.body.categories);
  }
  if (req.body.tags) post.tags = await resolveDocuments(Tag, req.body.tags);

  let message = "Post updated";
  if (req.user.role === ROLES.AUTHOR && post.status === "published") {
    post.status = "pending";
    post.publishedAt = null;
    message = "Published post moved back to pending approval";
  }

  await post.save();
  const data = await populatePost(Post.findById(post._id));
  res.json({ success: true, message, data });
});

exports.updateStatus = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw new AppError("Post not found", 404);
  if (req.user.role === ROLES.AUTHOR && !post.userID.equals(req.user._id)) {
    throw new AppError("You can only update your own posts", 403);
  }
  applyStatus(post, req.body.status, req.body.scheduledAt, req.user.role);
  await post.save();
  const data = await populatePost(Post.findById(post._id));
  res.json({ success: true, data });
});

exports.like = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.id).select("+likedBy");
  if (!post || post.status !== "published") throw new AppError("Post not found", 404);

  const already = post.likedBy.some((id) => id.equals(req.user._id));
  if (already) post.likedBy.pull(req.user._id);
  else {
    post.likedBy.push(req.user._id);
    await Analytics.create({ postID: post._id, userID: req.user._id, type: "like" });
  }
  post.likes = post.likedBy.length;
  await post.save();
  res.json({ success: true, data: { likes: post.likes, liked: !already } });
});

exports.remove = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw new AppError("Post not found", 404);
  if (!canEdit(post, req.user)) throw new AppError("You can only delete your own posts", 403);

  await Promise.all([
    post.deleteOne(),
    Comment.deleteMany({ postID: post._id }),
    Analytics.deleteMany({ postID: post._id }),
    Media.deleteMany({ postID: post._id }),
  ]);
  res.json({ success: true, message: "Post removed" });
});
