const Post = require("../models/postModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { getPage } = require("../utils/pagination");
const { escapeRegex } = require("../utils/slug");
const { ELEVATED_ROLES, POST_STATUSES } = require("../constants/roles");
const { publishDueScheduledPosts } = require("../services/postLifecycle");

exports.search = asyncHandler(async (req, res) => {
  const q = String(req.query.q || "").trim();
  if (q.length < 2 || q.length > 100) {
    throw new AppError("Search query must be 2 to 100 characters", 400);
  }

  await publishDueScheduledPosts();
  const { page, limit, skip } = getPage(req.query);
  const pattern = new RegExp(escapeRegex(q), "i");
  const filter = {
    $or: [{ name: pattern }, { message: pattern }, { summary: pattern }],
  };

  const elevated = req.user && ELEVATED_ROLES.includes(req.user.role);
  if (elevated && req.query.status && POST_STATUSES.includes(req.query.status)) {
    filter.status = req.query.status;
  } else {
    filter.status = "published";
  }

  const [data, total] = await Promise.all([
    Post.find(filter)
      .populate("userID", "name")
      .populate("categories", "name slug")
      .populate("tags", "name slug")
      .sort({ publishedAt: -1 })
      .skip(skip)
      .limit(limit),
    Post.countDocuments(filter),
  ]);

  res.json({ success: true, data, meta: { page, limit, total, q } });
});
