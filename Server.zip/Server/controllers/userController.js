const User = require("../models/userModel");
const Post = require("../models/postModel");
const Comment = require("../models/commentModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { publicUser } = require("../utils/publicUser");
const { getPage } = require("../utils/pagination");
const { ROLES } = require("../constants/roles");

async function assertNotLastAdmin(user) {
  if (user.role !== ROLES.ADMIN) return;
  const admins = await User.countDocuments({ role: ROLES.ADMIN });
  if (admins <= 1) throw new AppError("The last admin cannot be changed or removed", 400);
}

exports.list = asyncHandler(async (req, res) => {
  const { page, limit, skip } = getPage(req.query);
  const filter = {};
  if (req.query.role) filter.role = req.query.role;
  const [users, total] = await Promise.all([
    User.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit),
    User.countDocuments(filter),
  ]);
  res.json({
    success: true,
    data: users.map(publicUser),
    meta: { page, limit, total },
  });
});

exports.create = asyncHandler(async (req, res) => {
  const user = await User.create({
    name: req.body.name,
    email: req.body.email,
    password: req.body.password,
    role: req.body.role,
  });
  res.status(201).json({ success: true, data: publicUser(user) });
});

exports.getOne = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new AppError("User not found", 404);
  res.json({ success: true, data: publicUser(user) });
});

exports.updateRole = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new AppError("User not found", 404);
  if (user._id.equals(req.user._id)) {
    throw new AppError("You cannot change your own role", 400);
  }
  if (user.role === ROLES.ADMIN && req.body.role !== ROLES.ADMIN) {
    await assertNotLastAdmin(user);
  }
  user.role = req.body.role;
  await user.save();
  res.json({ success: true, data: publicUser(user) });
});

exports.remove = asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) throw new AppError("User not found", 404);
  if (user._id.equals(req.user._id)) throw new AppError("You cannot delete your own account", 400);
  await assertNotLastAdmin(user);

  const [posts, comments] = await Promise.all([
    Post.countDocuments({ userID: user._id }),
    Comment.countDocuments({ userID: user._id }),
  ]);
  if (posts || comments) {
    throw new AppError("User still owns posts or comments. Remove those records first.", 409);
  }

  await user.deleteOne();
  res.json({ success: true, message: "User removed" });
});
