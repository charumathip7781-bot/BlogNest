const Media = require("../models/mediaModel");
const Post = require("../models/postModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { isSafeMediaPath } = require("../utils/mediaPath");
const { ELEVATED_ROLES } = require("../constants/roles");

exports.create = asyncHandler(async (req, res) => {
  if (!isSafeMediaPath(req.body.path)) {
    throw new AppError("path must be a relative media path or an http(s) URL", 400);
  }

  let postID;
  if (req.body.postId) {
    const post = await Post.findById(req.body.postId);
    if (!post) throw new AppError("Post not found", 404);
    const elevated = ELEVATED_ROLES.includes(req.user.role);
    if (!elevated && !post.userID.equals(req.user._id)) {
      throw new AppError("You can only attach media to your own posts", 403);
    }
    postID = post._id;
    if (req.body.setAsCover) {
      post.photo = req.body.path.trim();
      await post.save();
    }
  }

  const data = await Media.create({
    userID: req.user._id,
    postID,
    path: req.body.path.trim(),
    filename: req.body.filename.trim(),
    mimeType: req.body.mimeType || "application/octet-stream",
    size: req.body.size || 0,
    alt: req.body.alt || "",
  });
  res.status(201).json({ success: true, data });
});

exports.list = asyncHandler(async (req, res) => {
  const filter = {};
  if (!ELEVATED_ROLES.includes(req.user.role)) filter.userID = req.user._id;
  if (req.query.postId) filter.postID = req.query.postId;
  const data = await Media.find(filter).sort({ createdAt: -1 });
  res.json({ success: true, data });
});

exports.remove = asyncHandler(async (req, res) => {
  const media = await Media.findById(req.params.id);
  if (!media) throw new AppError("Media record not found", 404);
  const elevated = ELEVATED_ROLES.includes(req.user.role);
  if (!elevated && !media.userID.equals(req.user._id)) {
    throw new AppError("You can only remove your own media records", 403);
  }
  await media.deleteOne();
  res.json({ success: true, message: "Media record removed" });
});
