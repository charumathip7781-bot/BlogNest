const Post = require("../models/postModel");
const Comment = require("../models/commentModel");
const User = require("../models/userModel");
const Analytics = require("../models/analyticsModel");
const asyncHandler = require("../utils/asyncHandler");
const AppError = require("../utils/AppError");
const { ELEVATED_ROLES } = require("../constants/roles");

function counts(rows) {
  return rows.reduce((acc, row) => {
    acc[row._id] = row.count;
    return acc;
  }, {});
}

exports.overview = asyncHandler(async (req, res) => {
  const [posts, users, comments] = await Promise.all([
    Post.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
    User.aggregate([{ $group: { _id: "$role", count: { $sum: 1 } } }]),
    Comment.aggregate([{ $group: { _id: "$status", count: { $sum: 1 } } }]),
  ]);
  res.json({
    success: true,
    data: {
      posts: counts(posts),
      users: counts(users),
      comments: counts(comments),
    },
  });
});

exports.postStats = asyncHandler(async (req, res) => {
  const post = await Post.findById(req.params.id);
  if (!post) throw new AppError("Post not found", 404);
  const elevated = ELEVATED_ROLES.includes(req.user.role);
  if (!elevated && !post.userID.equals(req.user._id)) {
    throw new AppError("You can only view analytics for your own posts", 403);
  }

  const [commentRows, recentEvents] = await Promise.all([
    Comment.aggregate([
      { $match: { postID: post._id } },
      { $group: { _id: "$status", count: { $sum: 1 } } },
    ]),
    Analytics.find({ postID: post._id }).sort({ createdAt: -1 }).limit(20),
  ]);

  res.json({
    success: true,
    data: {
      postID: post._id,
      name: post.name,
      status: post.status,
      views: post.views,
      likes: post.likes,
      comments: counts(commentRows),
      recentEvents,
    },
  });
});
