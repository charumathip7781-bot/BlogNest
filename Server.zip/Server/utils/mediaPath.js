function isSafeMediaPath(value) {
  if (typeof value !== "string") return false;
  const path = value.trim();
  if (!path || path.length > 500) return false;
  if (path.includes("..") || path.includes("\\") || path.includes("\0")) return false;
  if (/^javascript:/i.test(path) || /^data:/i.test(path)) return false;
  if (/^https?:\/\//i.test(path)) {
    try {
      const url = new URL(path);
      return url.protocol === "http:" || url.protocol === "https:";
    } catch {
      return false;
    }
  }
  return /^[\w./ -]+$/.test(path);
}

module.exports = { isSafeMediaPath };
