const MAX_ENTRIES = 300;
const entries = [];

function write(level, payload) {
  const entry = {
    level,
    time: new Date().toISOString(),
    ...payload,
  };
  entries.push(entry);
  if (entries.length > MAX_ENTRIES) entries.shift();
  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else console.log(line);
}

module.exports = {
  info(payload) {
    write("info", payload);
  },
  warn(payload) {
    write("warn", payload);
  },
  error(payload) {
    write("error", payload);
  },
  list() {
    return entries.slice().reverse();
  },
};
