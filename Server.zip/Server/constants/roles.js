const ROLES = Object.freeze({
  ADMIN: "admin",
  EDITOR: "editor",
  AUTHOR: "author",
  READER: "reader",
});

const ALL_ROLES = Object.values(ROLES);
const WRITE_ROLES = [ROLES.ADMIN, ROLES.EDITOR, ROLES.AUTHOR];
const ELEVATED_ROLES = [ROLES.ADMIN, ROLES.EDITOR];
const POST_STATUSES = ["draft", "pending", "scheduled", "published"];
const COMMENT_STATUSES = ["pending", "approved", "spam"];

module.exports = {
  ROLES,
  ALL_ROLES,
  WRITE_ROLES,
  ELEVATED_ROLES,
  POST_STATUSES,
  COMMENT_STATUSES,
};
