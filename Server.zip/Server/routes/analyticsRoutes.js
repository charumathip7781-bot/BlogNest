const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { mongoIdRule } = require("../middleware/validators");
const analytics = require("../controllers/analyticsController");
const { WRITE_ROLES, ELEVATED_ROLES } = require("../constants/roles");

const router = express.Router();

router.get("/overview", protect, authorize(...ELEVATED_ROLES), analytics.overview);
router.get("/posts/:id", protect, authorize(...WRITE_ROLES), mongoIdRule, validate, analytics.postStats);

module.exports = router;
