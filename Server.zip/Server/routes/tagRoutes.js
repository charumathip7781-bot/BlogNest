const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { tagRules, mongoIdRule } = require("../middleware/validators");
const tags = require("../controllers/tagController");
const { ELEVATED_ROLES } = require("../constants/roles");

const router = express.Router();

router.get("/", tags.list);
router.post("/", protect, authorize(...ELEVATED_ROLES), tagRules, validate, tags.create);
router.delete("/:id", protect, authorize(...ELEVATED_ROLES), mongoIdRule, validate, tags.remove);

module.exports = router;
