const express = require("express");
const { optionalAuth } = require("../middleware/auth");
const search = require("../controllers/searchController");

const router = express.Router();

router.get("/", optionalAuth, search.search);

module.exports = router;
