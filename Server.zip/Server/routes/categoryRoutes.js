const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { categoryRules, mongoIdRule } = require("../middleware/validators");
const categories = require("../controllers/categoryController");
const { ELEVATED_ROLES } = require("../constants/roles");

const router = express.Router();

router.get("/", categories.list);
router.post("/", protect, authorize(...ELEVATED_ROLES), categoryRules, validate, categories.create);
router.put("/:id", protect, authorize(...ELEVATED_ROLES), mongoIdRule, categoryRules, validate, categories.update);
router.delete("/:id", protect, authorize(...ELEVATED_ROLES), mongoIdRule, validate, categories.remove);

module.exports = router;
