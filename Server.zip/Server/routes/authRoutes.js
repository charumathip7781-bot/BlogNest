const express = require("express");
const { protect } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { authLimiter } = require("../middleware/rateLimiter");
const { registerRules, loginRules } = require("../middleware/validators");
const auth = require("../controllers/authController");

const router = express.Router();

router.post("/register", authLimiter, registerRules, validate, auth.register);
router.post("/login", authLimiter, loginRules, validate, auth.login);
router.get("/me", protect, auth.me);

module.exports = router;
