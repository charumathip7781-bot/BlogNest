const express = require("express");
const { protect, optionalAuth, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { commentRules, moderateRules, mongoIdRule } = require("../middleware/validators");
const comments = require("../controllers/commentController");
const { ALL_ROLES, ELEVATED_ROLES } = require("../constants/roles");

const postComments = express.Router({ mergeParams: true });
postComments.post("/", protect, authorize(...ALL_ROLES), commentRules, validate, comments.create);
postComments.get("/", optionalAuth, comments.list);

const moderation = express.Router();
moderation.patch("/:id", protect, authorize(...ELEVATED_ROLES), moderateRules, validate, comments.moderate);
moderation.delete("/:id", protect, mongoIdRule, validate, comments.remove);

module.exports = { postComments, moderation };
