const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { createUserRules, roleRules, mongoIdRule } = require("../middleware/validators");
const users = require("../controllers/userController");
const { ROLES } = require("../constants/roles");

const router = express.Router();

router.use(protect, authorize(ROLES.ADMIN));
router.get("/", users.list);
router.post("/", createUserRules, validate, users.create);
router.get("/:id", mongoIdRule, validate, users.getOne);
router.patch("/:id/role", roleRules, validate, users.updateRole);
router.delete("/:id", mongoIdRule, validate, users.remove);

module.exports = router;
