const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const { aiLimiter } = require("../middleware/rateLimiter");
const ai = require("../controllers/aiController");
const { WRITE_ROLES } = require("../constants/roles");

const router = express.Router();

router.use(aiLimiter, protect);
router.post("/generate-blog", authorize(...WRITE_ROLES), ai.generateBlog);
router.post("/summarize", ai.summarize);
router.post("/faq", ai.faq);
router.post("/weather", ai.weatherWise);
router.post("/weatherwise", ai.weatherWise);
router.post("/fittrack", ai.fitTrack);

module.exports = router;
