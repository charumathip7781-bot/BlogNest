const express = require("express");
const { protect, optionalAuth, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const {
  postWriteRules,
  postUpdateRules,
  statusRules,
  mongoIdRule,
} = require("../middleware/validators");
const posts = require("../controllers/postController");
const { WRITE_ROLES, ELEVATED_ROLES } = require("../constants/roles");

const router = express.Router();

function normalizePostBody(req, res, next) {
  if (!req.body.name && req.body.title) req.body.name = req.body.title;
  if (!req.body.message && req.body.content) req.body.message = req.body.content;
  if (!req.body.categories && req.body.category) {
    req.body.categories = Array.isArray(req.body.category)
      ? req.body.category
      : [req.body.category];
  }
  next();
}

router.get("/queue", protect, authorize(...ELEVATED_ROLES), posts.queue);
router.get("/mine", protect, authorize(...WRITE_ROLES), posts.mine);
router.get("/", optionalAuth, posts.list);
router.post("/", protect, authorize(...WRITE_ROLES), normalizePostBody, postWriteRules, validate, posts.create);
router.get("/:id", optionalAuth, mongoIdRule, validate, posts.getOne);
router.put("/:id", protect, authorize(...WRITE_ROLES), normalizePostBody, postUpdateRules, validate, posts.update);
router.patch("/:id/status", protect, authorize(...WRITE_ROLES), statusRules, validate, posts.updateStatus);
router.post("/:id/like", protect, mongoIdRule, validate, posts.like);
router.delete("/:id", protect, authorize(...WRITE_ROLES), mongoIdRule, validate, posts.remove);

module.exports = router;
