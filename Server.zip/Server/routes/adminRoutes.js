const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const admin = require("../controllers/adminController");
const { ROLES } = require("../constants/roles");

const router = express.Router();

router.get("/logs", protect, authorize(ROLES.ADMIN), admin.logs);

module.exports = router;
