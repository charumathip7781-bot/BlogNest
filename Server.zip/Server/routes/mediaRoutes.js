const express = require("express");
const { protect, authorize } = require("../middleware/auth");
const validate = require("../middleware/validate");
const { mediaRules, mongoIdRule } = require("../middleware/validators");
const media = require("../controllers/mediaController");
const { WRITE_ROLES } = require("../constants/roles");

const router = express.Router();

router.use(protect, authorize(...WRITE_ROLES));
router.get("/", media.list);
router.post("/", mediaRules, validate, media.create);
router.delete("/:id", mongoIdRule, validate, media.remove);

module.exports = router;
