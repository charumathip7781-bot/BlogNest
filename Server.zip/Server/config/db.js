const mongoose = require("mongoose");
const logger = require("../utils/logger");

async function connectDB() {
  const uri = process.env.MONGO_URI;
  if (!uri) {
    throw new Error("MONGO_URI is not set");
  }

  mongoose.set("strictQuery", true);
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 8000 });
  } catch (error) {
    const safeMessage = String(error.message || error.name).includes("@")
      ? error.name
      : error.message;
    logger.error({ message: "MongoDB connection failed", error: safeMessage });
    throw new Error(
      "MongoDB connection failed. Check that MongoDB is running and MONGO_URI is correct."
    );
  }

  logger.info({ message: "MongoDB connected" });
}

module.exports = connectDB;
