# How to test the BlogNest API

Base URL: `http://127.0.0.1:5050`

Start the API from the `Server` folder with `npm start`. MongoDB must already be running. In Postman, set the body type to **raw** and **JSON**, then send the requests in this order. Each write request needs the token from register or login.

`/api/blogs` and `/api/posts` are the same routes. The screenshots below use `/api/blogs`.

## 1. Register

`POST /api/auth/register`

```json
{
  "name": "john",
  "email": "john@gmail.com",
  "password": "123456"
}
```

A new email returns **201 Created**. The account role is `author`, so this user can create blogs and call the AI content API. Copy `token` from the response. Registering the same email again returns **409** with `email already exists`.

![Register user john](images/01-register.jpg)

## 2. Login

`POST /api/auth/login`

Use the account you just created, or the seeded author:

```json
{
  "email": "author@blognest.dev",
  "password": "Author@12345"
}
```

**200 OK** means login worked. Copy `token`. A wrong password returns **401** with `Invalid email or password`.

![Login as the seeded author](images/02-login.jpg)

For every request below, open **Authorization** or **Headers** and add:

```
Authorization: Bearer <token>
```

Do not send the token in the JSON body.

## 3. Create a blog

`POST /api/blogs`

```json
{
  "title": "My First Blog",
  "content": "This is my first blog content",
  "category": "Technology"
}
```

**201 Created** saves the post. `title` is stored as `name`, `content` is stored as `message`, and `category` is stored in `categories`. When `status` is omitted, the post is `published`, so it appears on `GET /api/blogs`.

![Create blog request and the start of the response](images/03-create-blog.jpg)

![Published blog with the Technology category](images/04-create-blog-response.jpg)

A reader token returns **403**. Only admin, editor, and author can create posts.

## 4. Check the AI content API

`POST /api/ai/generate-blog`

This is a separate request from creating a blog by hand. It asks Gemini to write a post from a topic. Use the same `Authorization: Bearer <token>` header. The signed-in user must be an author, editor, or admin.

```json
{
  "topic": "How a weekly content calendar keeps a blog on schedule",
  "tone": "practical",
  "audience": "new bloggers",
  "keywords": ["calendar", "publishing"],
  "save": true
}
```

| Field | Required | Meaning |
| --- | --- | --- |
| `topic` | Yes | 3 to 300 characters. This is the subject of the post. |
| `tone` | No | Writing style. Default is clear and practical. |
| `audience` | No | Who the post is for. |
| `keywords` | No | A string or an array of short labels. |
| `save` | No | `true` stores the result as a **draft**. Omit it, or send `false`, to only return the text. |

A successful call returns **201 Created**:

```json
{
  "success": true,
  "data": {
    "title": "How a Weekly Content Calendar Keeps Your Blog on Track",
    "content": "Four to six paragraphs of plain text.",
    "summary": "A short abstract.",
    "tags": ["Blogging", "Content Strategy"],
    "post": {
      "_id": "<draft id>",
      "status": "draft"
    }
  }
}
```

`post` is present only when `save` is `true`. That draft does not show up on `GET /api/blogs`, because the public list returns published posts only. Open it with the same token at `GET /api/posts/mine`.

The server uses the model in `GEMINI_MODEL`. That value is `gemini-3.8-flash`. `GEMINI_API_KEY` must be saved in `.env`, then the server must be restarted with `npm start`.

### What a failed AI call means

| Status | Message | What to do |
| --- | --- | --- |
| 401 | Authentication required | Add the Bearer token from login or register. |
| 403 | You do not have permission for this action | Log in as an author, editor, or admin. |
| 400 | topic must be 3 to 300 characters | Send a longer `topic`. |
| 503 | GEMINI_API_KEY is not configured | Save the key in `.env` and restart the server. |
| 503 | The AI model is busy right now | The server already retried Gemini. Wait a few seconds and send the request again. |

## 5. Optional: summarize a saved post

`POST /api/ai/summarize`

```json
{
  "postId": "<id from the create or generate response>"
}
```

Any signed-in user can summarize a published post. Summarizing a draft requires the owner, an editor, or an admin. The response includes `summary` and `metaDescription`.
