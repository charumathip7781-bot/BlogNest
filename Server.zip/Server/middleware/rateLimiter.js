const rateLimit = require("express-rate-limit");

function buildLimiter(max, windowMs) {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, message: "Too many requests. Try again later." },
  });
}

module.exports = {
  apiLimiter: buildLimiter(300, 15 * 60 * 1000),
  authLimiter: buildLimiter(20, 15 * 60 * 1000),
  aiLimiter: buildLimiter(30, 60 * 60 * 1000),
};
