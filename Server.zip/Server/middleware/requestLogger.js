const logger = require("../utils/logger");

function requestLogger(req, res, next) {
  const started = Date.now();
  res.on("finish", () => {
    logger.info({
      message: "request",
      method: req.method,
      path: req.originalUrl.split("?")[0],
      status: res.statusCode,
      ms: Date.now() - started,
      userID: req.user?._id,
    });
  });
  next();
}

module.exports = requestLogger;
