const SKIP_HTML_STRIP = new Set(["password"]);

function sanitizeValue(value, key) {
  if (Array.isArray(value)) return value.map((item) => sanitizeValue(item, key));
  if (value && typeof value === "object") return sanitizeObject(value);
  if (typeof value === "string" && !SKIP_HTML_STRIP.has(key)) {
    return value.replace(/<[^>]*>/g, "");
  }
  return value;
}

function sanitizeObject(source) {
  const clean = {};
  for (const [key, value] of Object.entries(source)) {
    if (
      key.startsWith("$") ||
      key.includes(".") ||
      key === "__proto__" ||
      key === "constructor" ||
      key === "prototype"
    ) {
      continue;
    }
    clean[key] = sanitizeValue(value, key);
  }
  return clean;
}

function sanitize(req, res, next) {
  if (req.body && typeof req.body === "object") req.body = sanitizeObject(req.body);
  if (req.query && typeof req.query === "object") {
    const cleanQuery = sanitizeObject(req.query);
    for (const key of Object.keys(req.query)) delete req.query[key];
    Object.assign(req.query, cleanQuery);
  }
  if (req.params && typeof req.params === "object") {
    const cleanParams = sanitizeObject(req.params);
    for (const key of Object.keys(req.params)) delete req.params[key];
    Object.assign(req.params, cleanParams);
  }
  next();
}

module.exports = sanitize;
