const { body, param } = require("express-validator");
const { ALL_ROLES, POST_STATUSES, COMMENT_STATUSES } = require("../constants/roles");

const registerRules = [
  body("name").trim().isLength({ min: 2, max: 80 }).withMessage("Name must be 2 to 80 characters"),
  body("email").trim().toLowerCase().isEmail().withMessage("A valid email is required"),
  body("password").isString().isLength({ min: 6, max: 128 }).withMessage("Password must be 6 to 128 characters"),
];

const loginRules = [
  body("email").trim().toLowerCase().isEmail().withMessage("A valid email is required"),
  body("password").isString().notEmpty().withMessage("Password is required"),
];

const createUserRules = [
  ...registerRules,
  body("role").isIn(ALL_ROLES).withMessage("Role must be admin, editor, author, or reader"),
];

const roleRules = [
  param("id").isMongoId().withMessage("Invalid user id"),
  body("role").isIn(ALL_ROLES).withMessage("Role must be admin, editor, author, or reader"),
];

const mongoIdRule = [param("id").isMongoId().withMessage("Invalid id")];

const postWriteRules = [
  body("name").trim().isLength({ min: 3, max: 180 }).withMessage("Title must be 3 to 180 characters"),
  body("message").trim().isLength({ min: 1, max: 50000 }).withMessage("Content is required"),
  body("photo").optional({ values: "falsy" }).isString().isLength({ max: 500 }),
  body("status").optional().isIn(POST_STATUSES),
  body("scheduledAt").optional({ values: "falsy" }).isISO8601(),
  body("categories").optional().isArray(),
  body("tags").optional().isArray(),
];

const postUpdateRules = [
  param("id").isMongoId().withMessage("Invalid post id"),
  body("name").optional().trim().isLength({ min: 3, max: 180 }),
  body("message").optional().trim().isLength({ min: 1, max: 50000 }),
  body("summary").optional().isString().isLength({ max: 1000 }),
  body("photo").optional({ values: "falsy" }).isString().isLength({ max: 500 }),
  body("categories").optional().isArray(),
  body("tags").optional().isArray(),
];

const statusRules = [
  param("id").isMongoId().withMessage("Invalid post id"),
  body("status").isIn(POST_STATUSES).withMessage("Invalid status"),
  body("scheduledAt").optional({ values: "falsy" }).isISO8601(),
];

const commentRules = [
  param("postId").isMongoId().withMessage("Invalid post id"),
  body("message").trim().isLength({ min: 1, max: 2000 }).withMessage("Comment must be 1 to 2000 characters"),
];

const moderateRules = [
  param("id").isMongoId().withMessage("Invalid comment id"),
  body("status").isIn(COMMENT_STATUSES).withMessage("Status must be pending, approved, or spam"),
];

const categoryRules = [
  body("name").trim().isLength({ min: 2, max: 40 }).withMessage("Name must be 2 to 40 characters"),
  body("description").optional().isString().isLength({ max: 300 }),
];

const tagRules = [
  body("name").trim().isLength({ min: 2, max: 40 }).withMessage("Name must be 2 to 40 characters"),
];

const mediaRules = [
  body("path").isString().isLength({ min: 1, max: 500 }).withMessage("path is required"),
  body("filename").trim().isLength({ min: 1, max: 180 }).withMessage("filename is required"),
  body("mimeType").optional().isString().isLength({ max: 120 }),
  body("size").optional().isInt({ min: 0 }),
  body("alt").optional().isString().isLength({ max: 180 }),
  body("postId").optional({ values: "falsy" }).isMongoId(),
  body("setAsCover").optional().isBoolean(),
];

module.exports = {
  registerRules,
  loginRules,
  createUserRules,
  roleRules,
  mongoIdRule,
  postWriteRules,
  postUpdateRules,
  statusRules,
  commentRules,
  moderateRules,
  categoryRules,
  tagRules,
  mediaRules,
};
