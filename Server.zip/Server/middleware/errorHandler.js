const logger = require("../utils/logger");

function errorHandler(err, req, res, next) {
  if (res.headersSent) return next(err);

  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({ success: false, message: "Invalid JSON body" });
  }

  if (err.name === "CastError") {
    return res.status(400).json({ success: false, message: "Invalid id" });
  }

  if (err.code === 11000) {
    const field = Object.keys(err.keyPattern || {})[0] || "value";
    return res.status(409).json({
      success: false,
      message: `${field} already exists`,
    });
  }

  if (err.name === "ValidationError") {
    const message = Object.values(err.errors)
      .map((item) => item.message)
      .join(", ");
    return res.status(400).json({ success: false, message });
  }

  const status = err.statusCode || err.status || 500;
  const message = status === 500 ? "Internal server error" : err.message;

  logger.error({
    message: err.message,
    status,
    method: req.method,
    path: req.originalUrl.split("?")[0],
  });

  return res.status(status).json({ success: false, message });
}

module.exports = errorHandler;
