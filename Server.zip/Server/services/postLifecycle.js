const Post = require("../models/postModel");
const AppError = require("../utils/AppError");
const { POST_STATUSES } = require("../constants/roles");

async function publishDueScheduledPosts() {
  const now = new Date();
  await Post.updateMany(
    { status: "scheduled", scheduledAt: { $lte: now } },
    { $set: { status: "published", publishedAt: now } }
  );
}

function applyStatus(post, status, scheduledAt, role, options = {}) {
  if (!POST_STATUSES.includes(status)) {
    throw new AppError("Invalid status", 400);
  }
  const authorMayPublish = options.allowAuthorPublish && status === "published";
  if (role === "author" && !["draft", "pending"].includes(status) && !authorMayPublish) {
    throw new AppError("Authors can move posts between draft and pending approval", 403);
  }
  if (status === "scheduled") {
    const when = new Date(scheduledAt);
    if (!scheduledAt || Number.isNaN(when.getTime()) || when.getTime() <= Date.now()) {
      throw new AppError("scheduledAt must be a future date", 400);
    }
    post.scheduledAt = when;
    post.publishedAt = null;
  }
  if (status === "published") {
    post.publishedAt = new Date();
    post.scheduledAt = null;
  }
  if (status === "draft" || status === "pending") {
    post.publishedAt = null;
    post.scheduledAt = null;
  }
  post.status = status;
}

module.exports = { publishDueScheduledPosts, applyStatus };
