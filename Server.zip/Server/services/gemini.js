const AppError = require("../utils/AppError");

let clientPromise;

function getModelName() {
  return process.env.GEMINI_MODEL || "gemini-3.8-flash";
}

async function getClient() {
  if (!process.env.GEMINI_API_KEY) {
    throw new AppError("GEMINI_API_KEY is not configured", 503);
  }
  if (!clientPromise) {
    clientPromise = import("@google/genai").then(({ GoogleGenAI }) => {
      return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    });
  }
  return clientPromise;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function geminiErrorDetails(error) {
  const raw = error?.message || "Gemini request failed";
  try {
    const parsed = JSON.parse(raw);
    const inner = parsed.error || parsed;
    return {
      code: Number(inner.code) || error.status,
      status: inner.status || "",
      message: inner.message || raw,
    };
  } catch {
    return { code: error?.status, status: "", message: raw };
  }
}

function isBusy(details) {
  return (
    details.code === 429 ||
    details.code === 503 ||
    details.status === "UNAVAILABLE" ||
    /high demand|try again later/i.test(details.message)
  );
}

function readGeneratedJson(response) {
  const text = response.text;
  if (!text) throw new AppError("Gemini returned an empty response", 502);

  try {
    return JSON.parse(text);
  } catch {
    const match = text.match(/\{[\s\S]*\}/);
    if (!match) throw new AppError("Gemini returned an unreadable response", 502);
    return JSON.parse(match[0]);
  }
}

async function generateJson(prompt, maxOutputTokens = 2048) {
  const ai = await getClient();
  const attempts = 3;

  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    try {
      const response = await ai.models.generateContent({
        model: getModelName(),
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          maxOutputTokens,
          temperature: 0.7,
        },
      });
      return readGeneratedJson(response);
    } catch (error) {
      if (error instanceof AppError) throw error;
      const details = geminiErrorDetails(error);
      if (!isBusy(details) || attempt === attempts) {
        throw new AppError(
          isBusy(details)
            ? "The AI model is busy right now. Wait a few seconds and send the request again."
            : details.message,
          isBusy(details) ? 503 : 502
        );
      }
      await sleep(1000 * attempt);
    }
  }
}

module.exports = { generateJson };
