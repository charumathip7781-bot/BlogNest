const mongoose = require("mongoose");
const AppError = require("../utils/AppError");
const { escapeRegex, slugify } = require("../utils/slug");

async function uniqueSlug(Model, base, ignoreId) {
  let slug = base;
  let suffix = 2;
  const exclude = ignoreId ? { _id: { $ne: ignoreId } } : {};
  while (await Model.exists({ slug, ...exclude })) {
    slug = `${base}-${suffix}`;
    suffix += 1;
  }
  return slug;
}

async function resolveDocuments(Model, values) {
  if (!values) return [];
  const list = Array.isArray(values) ? values : [values];
  const ids = [];

  for (const value of list) {
    if (value === null || value === undefined || value === "") continue;
    const raw = String(value).trim();
    if (!raw) continue;

    if (mongoose.isValidObjectId(raw)) {
      const existing = await Model.findById(raw);
      if (!existing) throw new AppError(`${Model.modelName} not found`, 400);
      ids.push(existing._id);
      continue;
    }

    const name = raw.slice(0, 40);
    let doc = await Model.findOne({
      name: new RegExp(`^${escapeRegex(name)}$`, "i"),
    });
    if (!doc) {
      doc = await Model.create({
        name,
        slug: await uniqueSlug(Model, slugify(name)),
      });
    }
    ids.push(doc._id);
  }

  return ids;
}

module.exports = { resolveDocuments, uniqueSlug };
