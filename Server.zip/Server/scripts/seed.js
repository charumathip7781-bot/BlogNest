require("dotenv").config();
const mongoose = require("mongoose");
const connectDB = require("../config/db");
const User = require("../models/userModel");
const Category = require("../models/categoryModel");
const Tag = require("../models/tagModel");
const Post = require("../models/postModel");
const { slugify } = require("../utils/slug");
const { uniqueSlug } = require("../services/taxonomy");

const USERS = [
  { name: "Asha Admin", email: "admin@blognest.dev", password: "Admin@12345", role: "admin" },
  { name: "Evan Editor", email: "editor@blognest.dev", password: "Editor@12345", role: "editor" },
  { name: "Priya Author", email: "author@blognest.dev", password: "Author@12345", role: "author" },
  { name: "Ravi Reader", email: "reader@blognest.dev", password: "Reader@12345", role: "reader" },
];

async function upsertUser(payload) {
  const existing = await User.findOne({ email: payload.email });
  if (existing) return existing;
  return User.create(payload);
}

async function upsertCategory(name, description) {
  const existing = await Category.findOne({ name });
  if (existing) return existing;
  return Category.create({
    name,
    description,
    slug: await uniqueSlug(Category, slugify(name)),
  });
}

async function upsertTag(name) {
  const existing = await Tag.findOne({ name });
  if (existing) return existing;
  return Tag.create({ name, slug: await uniqueSlug(Tag, slugify(name)) });
}

async function seed() {
  await connectDB();
  const users = {};
  for (const payload of USERS) {
    users[payload.role] = await upsertUser(payload);
  }

  const writing = await upsertCategory("Writing", "Drafting, editing, and publishing notes");
  const planning = await upsertTag("planning");
  const existingPost = await Post.findOne({ name: "How Priya organizes a week of drafts" });
  if (!existingPost) {
    await Post.create({
      userID: users.author._id,
      name: "How Priya organizes a week of drafts",
      message:
        "Priya keeps each draft in one place, files it under a category, and sends it for approval before it goes live. Views and likes stay attached to the published post so she can see what readers actually finish.",
      summary: "A short walkthrough of drafts, categories, and approval.",
      status: "published",
      publishedAt: new Date(),
      categories: [writing._id],
      tags: [planning._id],
    });
  }

  console.log("Seed complete");
  console.log("admin@blognest.dev / Admin@12345");
  console.log("editor@blognest.dev / Editor@12345");
  console.log("author@blognest.dev / Author@12345");
  console.log("reader@blognest.dev / Reader@12345");
  await mongoose.connection.close();
  process.exit(0);
}

seed().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
