const mongoose = require("mongoose");
const { COMMENT_STATUSES } = require("../constants/roles");

const commentSchema = new mongoose.Schema(
  {
    postID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post",
      required: true,
      index: true,
    },
    userID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    message: {
      type: String,
      required: [true, "Comment is required"],
      trim: true,
      minlength: 1,
      maxlength: 2000,
    },
    status: {
      type: String,
      enum: COMMENT_STATUSES,
      default: "pending",
      index: true,
    },
  },
  { timestamps: true, versionKey: false }
);

commentSchema.index({ postID: 1, status: 1 });

module.exports = mongoose.model("Comment", commentSchema);
