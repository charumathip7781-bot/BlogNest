const mongoose = require("mongoose");

const mediaSchema = new mongoose.Schema(
  {
    userID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    postID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Post",
    },
    path: {
      type: String,
      required: true,
      maxlength: 500,
    },
    filename: {
      type: String,
      required: true,
      maxlength: 180,
    },
    mimeType: {
      type: String,
      default: "application/octet-stream",
      maxlength: 120,
    },
    size: {
      type: Number,
      default: 0,
      min: 0,
    },
    alt: {
      type: String,
      default: "",
      maxlength: 180,
    },
  },
  { timestamps: true, versionKey: false }
);

module.exports = mongoose.model("Media", mediaSchema);
