const mongoose = require("mongoose");
const { POST_STATUSES } = require("../constants/roles");

const postSchema = new mongoose.Schema(
  {
    userID: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      index: true,
    },
    name: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
      minlength: 3,
      maxlength: 180,
    },
    photo: {
      type: String,
      default: "",
      maxlength: 500,
    },
    message: {
      type: String,
      required: [true, "Content is required"],
      maxlength: 50000,
    },
    summary: {
      type: String,
      default: "",
      maxlength: 1000,
    },
    likes: {
      type: Number,
      default: 0,
      min: 0,
    },
    likedBy: {
      type: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
      select: false,
      default: [],
    },
    views: {
      type: Number,
      default: 0,
      min: 0,
    },
    status: {
      type: String,
      enum: POST_STATUSES,
      default: "draft",
      index: true,
    },
    scheduledAt: Date,
    publishedAt: Date,
    categories: [{ type: mongoose.Schema.Types.ObjectId, ref: "Category" }],
    tags: [{ type: mongoose.Schema.Types.ObjectId, ref: "Tag" }],
  },
  { timestamps: true, versionKey: false }
);

postSchema.index({ status: 1, publishedAt: -1 });
postSchema.index({ userID: 1, status: 1 });

module.exports = mongoose.model("Post", postSchema);
